Compile index.tex twice with pdflatex from this folder.
